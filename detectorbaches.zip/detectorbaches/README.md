# 🕳️ Detector de Baches Tarapacá

Aplicación móvil Android desarrollada en Java para la detección, reporte y visualización de baches en la región de Tarapacá, integrando geolocalización, cámara segura, sincronización en tiempo real con Firebase Firestore, almacenamiento local con SQLite y detección de impactos mediante acelerómetro.

## 🚀 Características Principales
- **Autenticación Segura**: Inicio de sesión y registro de usuarios con Firebase Auth y protección contra capturas de pantalla (`FLAG_SECURE`).
- **Mapa Interactivo**: Visualización de baches reportados en tiempo real mediante Google Maps.
- **Reporte con Evidencia Fotográfica**: Captura de fotos mediante cámara utilizando `FileProvider` y compresión en formato Base64.
- **Modo Offline / Respaldo Local**: Almacenamiento local utilizando SQLite (`BacheDbHelper`).
- **Detección por Sensores**: Uso del acelerómetro (`SensorEventListener` y `ExecutorService`) para registrar movimientos bruscos.
- **Interfaz Adaptativa**: Listado de baches mediante `RecyclerView` y `CardView`.

---

## 🛠️ Tecnologías Utilizadas
- **Lenguaje**: Java
- **UI**: Android Views, Material Design, RecyclerView, CardView
- **Base de Datos Local**: SQLite
- **Base de Datos Cloud & Auth**: Firebase Firestore & Firebase Authentication
- **Mapas y Ubicación**: Google Maps API & Fused Location Provider
- **Sensores**: SensorManager / Acelerómetro

---

## 📱 Instalación y Ejecución
1. Clonar el repositorio o abrir el proyecto en **Android Studio**.
2. Sincronizar las dependencias de Gradle (`Sync Project with Gradle Files`).
3. Configurar tu clave de API de Google Maps en `AndroidManifest.xml` (`com.google.android.geo.API_KEY`).
4. Conectar un dispositivo físico o emulador Android (con soporte para Google Play Services).
5. Ejecutar la aplicación (`Run 'app'`).

---

## 🗄️ Estructura de Base de Datos

### SQLite (Local)
Tabla: `baches`
- `_id` (INTEGER, Primary Key, AutoIncrement)
- `latitud` (REAL)
- `longitud` (REAL)
- `descripcion` (TEXT)
- `foto` (TEXT - Base64)

### Cloud Firestore (Remoto)
Colección: `baches`
- `latitud` (Double)
- `longitud` (Double)
- `descripcion` (String)
- `fotoBase64` (String)
- `timestamp` (ServerTimestamp)
