package com.example.detectorbaches;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BacheAdapter extends RecyclerView.Adapter<BacheAdapter.BacheViewHolder> {

    private List<Bache> listaBaches;

    public BacheAdapter(List<Bache> listaBaches) {
        this.listaBaches = listaBaches;
    }

    @NonNull
    @Override
    public BacheViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_bache, parent, false);
        return new BacheViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BacheViewHolder holder, int position) {
        Bache bache = listaBaches.get(position);
        holder.tvDescripcion.setText(bache.getDescripcion() != null && !bache.getDescripcion().isEmpty() ? bache.getDescripcion() : "Sin descripción");
        holder.tvUbicacion.setText(String.format("Lat: %.4f, Lng: %.4f", bache.getLatitud(), bache.getLongitud()));

        String fotoBase64 = bache.getFotoBase64();
        if (fotoBase64 != null && !fotoBase64.isEmpty()) {
            try {
                byte[] decodedBytes = Base64.decode(fotoBase64, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
                holder.ivFoto.setImageBitmap(bitmap);
            } catch (Exception e) {
                holder.ivFoto.setImageResource(android.R.drawable.ic_menu_report_image);
            }
        } else {
            holder.ivFoto.setImageResource(android.R.drawable.ic_menu_report_image);
        }
    }

    @Override
    public int getItemCount() {
        return listaBaches.size();
    }

    public static class BacheViewHolder extends RecyclerView.ViewHolder {
        ImageView ivFoto;
        TextView tvDescripcion, tvUbicacion;

        public BacheViewHolder(@NonNull View itemView) {
            super(itemView);
            ivFoto = itemView.findViewById(R.id.ivBacheFoto);
            tvDescripcion = itemView.findViewById(R.id.tvBacheDescripcion);
            tvUbicacion = itemView.findViewById(R.id.tvBacheUbicacion);
        }
    }
}
