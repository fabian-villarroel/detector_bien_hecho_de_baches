package com.example.detectorbaches;

import android.provider.BaseColumns;

public final class BacheContract {

    private BacheContract() {
    }

    public static class BacheEntry implements BaseColumns {
        public static final String TABLE_NAME = "baches";
        public static final String COLUMN_LATITUD = "latitud";
        public static final String COLUMN_LONGITUD = "longitud";
        public static final String COLUMN_DESCRIPCION = "descripcion";
        public static final String COLUMN_FOTO = "foto_base64";
    }
}