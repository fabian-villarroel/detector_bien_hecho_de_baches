package com.example.detectorbaches;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class BacheDbHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "detector_baches.db";
    public static final int DATABASE_VERSION = 1;

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + BacheContract.BacheEntry.TABLE_NAME + " (" +
                    BacheContract.BacheEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    BacheContract.BacheEntry.COLUMN_LATITUD + " REAL," +
                    BacheContract.BacheEntry.COLUMN_LONGITUD + " REAL," +
                    BacheContract.BacheEntry.COLUMN_DESCRIPCION + " TEXT," +
                    BacheContract.BacheEntry.COLUMN_FOTO + " TEXT)";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + BacheContract.BacheEntry.TABLE_NAME;

    public BacheDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }

    // 1. CREAR (Insert)
    public long insertBache(double lat, double lng, String desc, String foto) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(BacheContract.BacheEntry.COLUMN_LATITUD, lat);
        values.put(BacheContract.BacheEntry.COLUMN_LONGITUD, lng);
        values.put(BacheContract.BacheEntry.COLUMN_DESCRIPCION, desc);
        values.put(BacheContract.BacheEntry.COLUMN_FOTO, foto);
        return db.insert(BacheContract.BacheEntry.TABLE_NAME, null, values);
    }

    // 2. LEER (Select todos)
    public List<Bache> getAllBaches() {
        List<Bache> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                BacheContract.BacheEntry.TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                BacheContract.BacheEntry._ID + " DESC"
        );

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(BacheContract.BacheEntry._ID));
            double lat = cursor.getDouble(cursor.getColumnIndexOrThrow(BacheContract.BacheEntry.COLUMN_LATITUD));
            double lng = cursor.getDouble(cursor.getColumnIndexOrThrow(BacheContract.BacheEntry.COLUMN_LONGITUD));
            String desc = cursor.getString(cursor.getColumnIndexOrThrow(BacheContract.BacheEntry.COLUMN_DESCRIPCION));
            String foto = cursor.getString(cursor.getColumnIndexOrThrow(BacheContract.BacheEntry.COLUMN_FOTO));

            lista.add(new Bache(id, lat, lng, desc, foto));
        }
        cursor.close();
        return lista;
    }

    // 3. ACTUALIZAR (Update parametrizado)
    public int updateBache(int id, String nuevaDescripcion) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(BacheContract.BacheEntry.COLUMN_DESCRIPCION, nuevaDescripcion);

        String whereClause = BacheContract.BacheEntry._ID + " = ?";
        String[] whereArgs = { String.valueOf(id) };

        return db.update(BacheContract.BacheEntry.TABLE_NAME, values, whereClause, whereArgs);
    }

    // 4. ELIMINAR (Delete parametrizado)
    public int deleteBache(int id) {
        SQLiteDatabase db = getWritableDatabase();
        String whereClause = BacheContract.BacheEntry._ID + " = ?";
        String[] whereArgs = { String.valueOf(id) };

        return db.delete(BacheContract.BacheEntry.TABLE_NAME, whereClause, whereArgs);
    }
}
