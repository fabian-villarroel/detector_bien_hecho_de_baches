package com.example.detectorbaches;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ListaBachesActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private BacheAdapter adapter;
    private BacheDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_baches);

        Toolbar toolbar = findViewById(R.id.toolbarLista);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            toolbar.setNavigationOnClickListener(v -> finish());
        }

        recyclerView = findViewById(R.id.recyclerViewBaches);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new BacheDbHelper(this);
        List<Bache> listaBaches = dbHelper.getAllBaches();

        adapter = new BacheAdapter(listaBaches);
        recyclerView.setAdapter(adapter);
    }
}
