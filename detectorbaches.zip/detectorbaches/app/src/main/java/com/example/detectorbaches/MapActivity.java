package com.example.detectorbaches;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;

import org.osmdroid.config.Configuration;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MapActivity extends FragmentActivity implements SensorEventListener {

    private MapView map;
    private FusedLocationProviderClient fusedLocationClient;
    private Location ubicacionActual;
    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int PERMISSION_REQUEST_CODE = 100;

    private Bitmap fotoCapturada = null;
    private Uri photoUri;
    private List<Marker> listaMarcadoresBaches = new ArrayList<>();

    private FirebaseFirestore db;
    private BacheDbHelper dbHelper;
    private ListenerRegistration bachesListener;

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private ExecutorService executorService;
    private long lastUpdate = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inicializar configuración de OSMDroid antes de setContentView
        Configuration.getInstance().load(getApplicationContext(), android.preference.PreferenceManager.getDefaultSharedPreferences(getApplicationContext()));
        Configuration.getInstance().setUserAgentValue("DetectorBachesApp");

        setContentView(R.layout.activity_map);

        db = FirebaseFirestore.getInstance();
        dbHelper = new BacheDbHelper(this);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        }
        executorService = Executors.newSingleThreadExecutor();

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        map = findViewById(R.id.map);
        map.setTileSource(org.osmdroid.tileprovider.tilesource.TileSourceFactory.OpenTopo);
        map.setMultiTouchControls(true);
        map.getController().setZoom(13.0);
        GeoPoint startPoint = new GeoPoint(-20.244, -70.138); // Iquique / Alto Hospicio
        map.getController().setCenter(startPoint);

        obtenerUbicacionYVerificarAlerta();
        escucharBachesEnFirestore();

        Button btnTomarFoto = findViewById(R.id.btnTomarFoto);
        btnTomarFoto.setOnClickListener(v -> abrirCamara());

        Button btnVerLista = findViewById(R.id.btnVerLista);
        btnVerLista.setOnClickListener(v -> {
            Intent intent = new Intent(MapActivity.this, ListaBachesActivity.class);
            startActivity(intent);
        });

        pedirPermisos();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (map != null) map.onResume();
        if (sensorManager != null && accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (map != null) map.onPause();
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            float gSum = (x * x + y * y + z * z) / (SensorManager.GRAVITY_EARTH * SensorManager.GRAVITY_EARTH);
            if (gSum > 2.5f) {
                long curTime = System.currentTimeMillis();
                if ((curTime - lastUpdate) > 2000) {
                    lastUpdate = curTime;
                    executorService.execute(() -> {
                        // Tarea en segundo plano con ExecutorService
                    });
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    private void pedirPermisos() {
        ActivityCompat.requestPermissions(this,
                new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.CAMERA
                },
                PERMISSION_REQUEST_CODE);
    }

    private void obtenerUbicacionYVerificarAlerta() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
                if (location != null) {
                    ubicacionActual = location;
                    GeoPoint userPoint = new GeoPoint(location.getLatitude(), location.getLongitude());
                    map.getController().setCenter(userPoint);
                    verificarBachesCercanos(location);
                }
            });
        }
    }

    private void escucharBachesEnFirestore() {
        bachesListener = db.collection("baches")
                .addSnapshotListener((snapshots, error) -> {
                    if (error != null || snapshots == null || map == null) {
                        return;
                    }

                    // Remover marcadores anteriores de baches
                    for (Marker m : listaMarcadoresBaches) {
                        map.getOverlays().remove(m);
                    }
                    listaMarcadoresBaches.clear();

                    for (DocumentSnapshot doc : snapshots.getDocuments()) {
                        Double lat = doc.getDouble("latitud");
                        Double lng = doc.getDouble("longitud");
                        String desc = doc.getString("descripcion");
                        String fotoBase64 = doc.getString("fotoBase64");

                        if (lat != null && lng != null) {
                            GeoPoint pos = new GeoPoint(lat, lng);

                            Marker marker = new Marker(map);
                            marker.setPosition(pos);
                            marker.setTitle("Bache reportado");
                            marker.setSnippet(desc != null ? desc : "Sin descripción");
                            marker.setSubDescription(fotoBase64 != null ? fotoBase64 : "");

                            marker.setOnMarkerClickListener((m, mapView) -> {
                                String foto = m.getSubDescription();
                                mostrarDetalleBache(m.getTitle(), m.getSnippet(), foto);
                                return true;
                            });

                            map.getOverlays().add(marker);
                            listaMarcadoresBaches.add(marker);
                        }
                    }
                    map.invalidate();

                    if (ubicacionActual != null) {
                        verificarBachesCercanos(ubicacionActual);
                    }
                });
    }

    // Alerta de proximidad si el conductor está a menos de 100 metros
    private void verificarBachesCercanos(Location miUbicacion) {
        for (Marker marker : listaMarcadoresBaches) {
            Location locBache = new Location("");
            locBache.setLatitude(marker.getPosition().getLatitude());
            locBache.setLongitude(marker.getPosition().getLongitude());

            float distanciaMetros = miUbicacion.distanceTo(locBache);
            if (distanciaMetros < 100) {
                new AlertDialog.Builder(this)
                        .setTitle("⚠️ ¡PRECAUCIÓN!")
                        .setMessage("Hay un bache reportado a unos " + (int) distanciaMetros + " metros de tu posición.")
                        .setPositiveButton("Entendido", null)
                        .show();
                break;
            }
        }
    }

    private void abrirCamara() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                java.io.File photoFile = java.io.File.createTempFile(
                        "bache_" + System.currentTimeMillis(),
                        ".jpg",
                        getCacheDir()
                );
                photoUri = androidx.core.content.FileProvider.getUriForFile(
                        this,
                        getPackageName() + ".fileprovider",
                        photoFile
                );
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                takePictureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
            } catch (java.io.IOException e) {
                Toast.makeText(this, "Error al preparar archivo de foto", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK && photoUri != null) {
            try {
                fotoCapturada = MediaStore.Images.Media.getBitmap(getContentResolver(), photoUri);
                pedirDescripcionYGuardar();
            } catch (java.io.IOException e) {
                Toast.makeText(this, "Error al leer la foto capturada", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void pedirDescripcionYGuardar() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Describir el bache");

        final EditText input = new EditText(this);
        input.setHint("Ej: Bache grande en la pista derecha");
        builder.setView(input);

        builder.setPositiveButton("Guardar reporte", (dialog, which) -> {
            String descripcion = input.getText().toString().trim();
            Location loc = ubicacionActual;
            Bitmap foto = fotoCapturada;

            if (loc == null) {
                Toast.makeText(this, "Esperando ubicación GPS... Intente de nuevo en un momento.", Toast.LENGTH_SHORT).show();
                obtenerUbicacionYVerificarAlerta();
                return;
            }
            if (foto == null) {
                Toast.makeText(this, "No se ha capturado ninguna foto", Toast.LENGTH_SHORT).show();
                return;
            }

            guardarBacheEnFirebaseYSQLite(
                    descripcion,
                    loc.getLatitude(),
                    loc.getLongitude(),
                    foto
            );
        });

        builder.setNegativeButton("Cancelar", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void guardarBacheEnFirebaseYSQLite(String descripcion, double lat, double lng, Bitmap bitmap) {
        new Thread(() -> {
            Bitmap mini = Bitmap.createScaledBitmap(bitmap, 400, 400, true);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            mini.compress(Bitmap.CompressFormat.JPEG, 60, baos);
            String fotoBase64 = android.util.Base64.encodeToString(baos.toByteArray(), android.util.Base64.DEFAULT);

            dbHelper.insertBache(lat, lng, descripcion, fotoBase64);

            Map<String, Object> bache = new HashMap<>();
            bache.put("latitud", lat);
            bache.put("longitud", lng);
            bache.put("descripcion", descripcion);
            bache.put("fotoBase64", fotoBase64);
            bache.put("timestamp", FieldValue.serverTimestamp());

            db.collection("baches")
                    .add(bache)
                    .addOnSuccessListener(docRef ->
                            runOnUiThread(() -> Toast.makeText(MapActivity.this, "¡Bache reportado en Firebase!", Toast.LENGTH_SHORT).show()))
                    .addOnFailureListener(e ->
                            runOnUiThread(() -> Toast.makeText(MapActivity.this, "Error al guardar en Firestore", Toast.LENGTH_SHORT).show()));
        }).start();
    }

    private void mostrarDetalleBache(String titulo, String descripcion, String fotoBase64) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(titulo);

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);

        android.widget.TextView tvDesc = new android.widget.TextView(this);
        tvDesc.setText(descripcion != null ? descripcion : "Sin descripción");
        layout.addView(tvDesc);

        if (fotoBase64 != null && !fotoBase64.isEmpty()) {
            try {
                byte[] decodedBytes = android.util.Base64.decode(fotoBase64, android.util.Base64.DEFAULT);
                Bitmap decodedBitmap = android.graphics.BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
                if (decodedBitmap != null) {
                    android.widget.ImageView ivFoto = new android.widget.ImageView(this);
                    ivFoto.setImageBitmap(decodedBitmap);
                    ivFoto.setAdjustViewBounds(true);
                    ivFoto.setPadding(0, 20, 0, 0);
                    layout.addView(ivFoto);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        builder.setView(layout);
        builder.setPositiveButton("Cerrar", null);
        builder.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (bachesListener != null) {
            bachesListener.remove();
        }
        if (executorService != null) {
            executorService.shutdown();
        }
    }
}
