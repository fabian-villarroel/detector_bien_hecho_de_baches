package com.example.detectorbaches;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {

    private EditText etCorreo, etClave;
    private Button btnEnviarRegistro;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        getWindow().setFlags(
                android.view.WindowManager.LayoutParams.FLAG_SECURE,
                android.view.WindowManager.LayoutParams.FLAG_SECURE
        );

        mAuth = FirebaseAuth.getInstance();

        etCorreo = findViewById(R.id.etCorreo);
        etClave = findViewById(R.id.etClave);
        btnEnviarRegistro = findViewById(R.id.btnEnviarRegistro);

        btnEnviarRegistro.setOnClickListener(v -> registrarUsuario());
    }

    private void registrarUsuario() {
        String correo = etCorreo.getText().toString().trim();
        String clave = etClave.getText().toString().trim();

        if (correo.isEmpty() || clave.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        mAuth.createUserWithEmailAndPassword(correo, clave)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(RegisterActivity.this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(RegisterActivity.this, MapActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        String mensajeError = (task.getException() != null)
                                ? task.getException().getMessage()
                                : "Error en registro";
                        Toast.makeText(RegisterActivity.this, mensajeError, Toast.LENGTH_LONG).show();
                    }
                });
    }
}